// db.js
const { Pool } = require("pg");

const pool = new Pool({
  connectionString: "postgresql://neondb_owner:npg_b1LGWdwkHl6S@ep-curly-thunder-ad5c4z7m-pooler.c-2.us-east-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require"
});

module.exports = pool;
